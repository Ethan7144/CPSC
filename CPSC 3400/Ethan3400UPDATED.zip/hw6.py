#Ethan Tarlov
#hw6.py
#3/6/22

"""Template for answers to be submitted as Part 1 of HW6, CPSC 3400, Spring 2021
ONLY change the string constants below and hand in this file after RENAMING it
to hw6.py. You can use (and modify) hw6_test.py to test your submission. Do NOT
hand in hw6_template.py or hw6_test.py.
"""

a = r'^[0-46-9]*5[0-46-9]*5[0-46-9]*$' 
b = r'^((0{0,1}[1-9])|(1[0-2])):[0-5][0-9] (A|P)M$)' 
c = r'^[A-Za-z_]+[A-Za-z0-9_]*(,[A-Za-z_]+[A-Za-z0-9_]*)*$'
d = r'([A-Za-z0-9]+)()*<()*([A-Za-z0-9]+)'
d_sub = r'([A-Za-z0-9]+)()*<=()*([A-Za-z0-9]+)'
